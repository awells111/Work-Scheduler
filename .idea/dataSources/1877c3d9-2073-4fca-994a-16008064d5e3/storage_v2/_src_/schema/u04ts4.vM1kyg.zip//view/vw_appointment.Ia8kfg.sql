create view vw_appointment as
  select
    `u04ts4`.`appointment`.`appointmentId` AS `appointmentId`,
    `u04ts4`.`appointment`.`customerId`    AS `customerId`,
    `u04ts4`.`appointment`.`title`         AS `title`,
    `u04ts4`.`appointment`.`start`         AS `start`,
    `u04ts4`.`appointment`.`end`           AS `end`
  from `u04ts4`.`appointment`;

