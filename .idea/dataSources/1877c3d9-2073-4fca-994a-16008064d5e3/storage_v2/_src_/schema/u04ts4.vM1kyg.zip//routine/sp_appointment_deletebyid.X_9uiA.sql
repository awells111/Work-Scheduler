create procedure sp_appointment_DeleteById(IN var_appointmentId int(10))
  BEGIN
	DELETE FROM appointment
    WHERE appointmentId = var_appointmentId;
END;

