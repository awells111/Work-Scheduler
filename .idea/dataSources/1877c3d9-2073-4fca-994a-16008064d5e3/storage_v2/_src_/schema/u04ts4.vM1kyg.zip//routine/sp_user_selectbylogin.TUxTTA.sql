create procedure sp_user_SelectByLogin(IN var_userName varchar(50), IN var_password varchar(50))
  BEGIN
	SELECT * FROM user WHERE userName = var_userName AND password = var_password;
END;

