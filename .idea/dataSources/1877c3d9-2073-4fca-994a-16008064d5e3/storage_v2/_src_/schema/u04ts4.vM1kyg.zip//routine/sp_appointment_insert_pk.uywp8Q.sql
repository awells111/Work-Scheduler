create procedure sp_appointment_Insert_pk(IN var_customerId int(10), IN var_title varchar(255), IN var_start datetime,
                                          IN var_end        datetime)
  BEGIN
	CALL `u04ts4`.`sp_appointment_Insert`(var_customerId, var_title, var_start, var_end);

	SELECT LAST_INSERT_ID();
END;

