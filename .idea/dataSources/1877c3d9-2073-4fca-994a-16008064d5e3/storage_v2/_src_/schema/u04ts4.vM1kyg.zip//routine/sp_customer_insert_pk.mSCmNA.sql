create procedure sp_customer_Insert_pk(IN var_customerName varchar(45), IN var_address varchar(50),
                                       IN var_phone        varchar(20))
  BEGIN

	CALL `u04ts4`.`sp_customer_Insert`(var_customerName, var_address, var_phone);

    SELECT LAST_INSERT_ID();
END;

