create procedure sp_appointment_UpdateById(IN var_title         varchar(255), IN var_start datetime,
                                           IN var_end           datetime, IN var_appointmentId int(10))
  BEGIN
UPDATE appointment SET title = var_title, start = var_start, end = var_end WHERE appointmentId = var_appointmentId;
END;

