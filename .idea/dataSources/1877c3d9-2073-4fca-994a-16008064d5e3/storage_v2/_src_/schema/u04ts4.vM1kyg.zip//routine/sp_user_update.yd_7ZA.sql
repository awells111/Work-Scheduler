create procedure sp_user_Update(IN var_userId int(10), IN var_userName varchar(50), IN var_password varchar(50))
  BEGIN
	/*Update user*/
    UPDATE user 
    SET userName = var_userName, 
		password = var_password 
	WHERE userId = var_userId;
END;

