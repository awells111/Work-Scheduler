create procedure sp_customer_Update(IN var_customerId int(10), IN var_customerName varchar(45),
                                    IN var_address    varchar(50), IN var_phone varchar(20))
  BEGIN
	/*Update customer*/
    UPDATE customer SET customerName = var_customerName WHERE customerId = var_customerId;
    
    /*Update address*/
    UPDATE address SET address = var_address, phone = var_phone WHERE customerId = var_customerId;
END;

