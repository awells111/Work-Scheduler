create procedure sp_user_Insert(IN var_userName varchar(50), IN var_password varchar(50))
  BEGIN
	/*Insert user*/
    INSERT INTO `u04ts4`.`user`(userName, password) VALUES (var_userName, var_password);
END;

