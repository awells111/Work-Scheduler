create procedure sp_customer_Insert(IN var_customerName varchar(45), IN var_address varchar(50),
                                    IN var_phone        varchar(20))
  BEGIN
	/*Insert customer*/
    INSERT INTO customer(customerName) VALUES (var_customerName);
    
    /*Insert address*/
    INSERT INTO address(customerId, address, phone) VALUES (LAST_INSERT_ID(), var_address, var_phone);
END;

