create procedure sp_appointment_Insert(IN var_customerId int(10), IN var_title varchar(255), IN var_start datetime,
                                       IN var_end        datetime)
  BEGIN
	/*Insert an appointment into the database*/
	INSERT INTO appointment(customerId, title, start, end) 
    VALUES (var_customerId, var_title, var_start, var_end);
END;

