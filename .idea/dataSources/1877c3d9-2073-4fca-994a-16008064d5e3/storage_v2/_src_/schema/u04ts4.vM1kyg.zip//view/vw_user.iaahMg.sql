create view vw_user as
  select
    `u04ts4`.`user`.`userName` AS `userName`,
    `u04ts4`.`user`.`password` AS `password`
  from `u04ts4`.`user`;

