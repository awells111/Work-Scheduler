create trigger customer_BEFORE_INSERT
  before INSERT
  on customer
  for each row
  BEGIN
   DECLARE currentUser varchar(50);

   -- Find userName of person performing INSERT into table
   SELECT USER() INTO currentUser;

   -- Update createdBy field to the username of the person performing the INSERT
   SET NEW.createdBy = currentUser;
   
   -- Update lastUpdateBy field to the username of the person performing the INSERT
   SET NEW.lastUpdateBy = currentUser;
END;

