create view vw_customer as
  select
    `u04ts4`.`customer`.`customerId`   AS `customerId`,
    `u04ts4`.`customer`.`customerName` AS `customerName`,
    `u04ts4`.`address`.`address`       AS `address`,
    `u04ts4`.`address`.`phone`         AS `phone`
  from (`u04ts4`.`customer`
    join `u04ts4`.`address` on ((`u04ts4`.`customer`.`customerId` = `u04ts4`.`address`.`customerId`)));

