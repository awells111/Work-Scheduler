create procedure sp_appointment_SelectClose()
  BEGIN
	/*Select appointments that start within 15 minutes of now*/
	SELECT * FROM appointment
    WHERE (now() < start)
		AND (start < now() + INTERVAL 15 MINUTE);
END;

