create trigger customer_BEFORE_UPDATE
  before UPDATE
  on customer
  for each row
  BEGIN
   DECLARE currentUser varchar(50);

   -- Find userName of person performing UPDATE
   SELECT USER() INTO currentUser;

   -- Update lastUpdateBy field to the username of the person performing the UPDATE
   SET NEW.lastUpdateBy = currentUser;
END;

