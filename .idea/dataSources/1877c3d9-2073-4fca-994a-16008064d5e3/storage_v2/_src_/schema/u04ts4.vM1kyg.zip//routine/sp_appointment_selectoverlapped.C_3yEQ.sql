create procedure sp_appointment_SelectOverlapped(IN var_customerId int(10), IN var_appointmentId int(10),
                                                 IN var_start      datetime, IN var_end datetime)
  BEGIN
	SELECT count(*) 
	FROM appointment 
	WHERE customerId = var_customerId 
		AND appointmentId != var_appointmentId 
		AND (
			(var_start > start AND var_start < end) 
			OR (var_end > start AND var_end < end) 
			OR (var_start <= start AND var_end >= end)
            );
END;

