create procedure sp_customer_DeleteById(IN var_customerId int(10))
  BEGIN
	DELETE FROM customer WHERE customerId = var_customerId;
END;

